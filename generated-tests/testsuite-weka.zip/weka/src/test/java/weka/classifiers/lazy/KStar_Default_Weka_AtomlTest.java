package weka.classifiers.lazy;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;


import javax.annotation.Generated;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import weka.classifiers.Classifier;
import weka.classifiers.AbstractClassifier;
import weka.core.Instances;
import weka.core.Instance;

/**
 * Automatically generated smoke and metamorphic tests.
 */
@Generated("atoml.testgen.TestclassGenerator")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class KStar_Default_Weka_AtomlTest {

    @Test(timeout=21600000)
    public void test_Const_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Const.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Const.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Const_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Const.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Const.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Const_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Const.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Const.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Const_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Const.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Const.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Opposite_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + "_Opposite.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + "_Opposite.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Scramble_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + "_Scramble.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + "_Scramble.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Reorder_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + "_Reorder.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + "_Reorder.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Same_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + "_Same.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + "_Same.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(data.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDNUM_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDNUM_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNIFORM_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNIFORM_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/RANDCAT_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/RANDCAT_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CATEGORICAL_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CATEGORICAL_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/CREDITG_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/CREDITG_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/IONOSPHERE_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/IONOSPHERE_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/UNBALANCE_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/UNBALANCE_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNOMINAL_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNOMINAL_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Rename_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Instances data;
            InputStreamReader originalFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + ".arff"));
            try(BufferedReader reader = new BufferedReader(originalFile);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + ".arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances morphedData;
            InputStreamReader morphedFile = new InputStreamReader(
                     this.getClass().getResourceAsStream("/morphdata/WEATHERNUMERIC_" + iter + "_Rename.arff"));
            try(BufferedReader reader = new BufferedReader(morphedFile);) {
                morphedData = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  morphdata/WEATHERNUMERIC_" + iter + "_Rename.arff", e);
            }
            morphedData.setClassIndex(morphedData.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
		    classifier.buildClassifier(data);
            Classifier morphedClassifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            morphedClassifier.buildClassifier(morphedData);
            int violations = 0;
            for (int i = 0; i < data.size(); i++) {
                double originalClass = classifier.classifyInstance(data.instance(i));
			    double morphedClass = morphedClassifier.classifyInstance(morphedData.instance(i));

                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Uniform() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Uniform_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Uniform_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Uniform_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Uniform_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_MinFloat() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MinFloat_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MinFloat_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MinFloat_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MinFloat_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_VerySmall() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/VerySmall_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/VerySmall_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/VerySmall_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/VerySmall_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_MinDouble() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MinDouble_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MinDouble_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MinDouble_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MinDouble_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_MaxFloat() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MaxFloat_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MaxFloat_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MaxFloat_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MaxFloat_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_VeryLarge() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/VeryLarge_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/VeryLarge_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/VeryLarge_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/VeryLarge_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_MaxDouble() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MaxDouble_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MaxDouble_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/MaxDouble_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/MaxDouble_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Split() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Split_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Split_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Split_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Split_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_LeftSkew() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/LeftSkew_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/LeftSkew_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/LeftSkew_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/LeftSkew_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_RightSkew() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RightSkew_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RightSkew_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RightSkew_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RightSkew_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_OneClass() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/OneClass_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/OneClass_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/OneClass_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/OneClass_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Bias() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Bias_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Bias_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Bias_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Bias_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Outlier() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Outlier_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Outlier_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Outlier_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Outlier_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_Zeroes() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Zeroes_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Zeroes_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/Zeroes_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/Zeroes_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_RandomNumeric() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RandomNumeric_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RandomNumeric_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RandomNumeric_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RandomNumeric_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_RandomCategorial() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RandomCategorial_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RandomCategorial_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/RandomCategorial_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/RandomCategorial_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_DisjointNumeric() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/DisjointNumeric_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/DisjointNumeric_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/DisjointNumeric_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/DisjointNumeric_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_DisjointCategorical() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/DisjointCategorical_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/DisjointCategorical_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/DisjointCategorical_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/DisjointCategorical_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_ManyCategories() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/ManyCategories_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/ManyCategories_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/ManyCategories_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/ManyCategories_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_StarvedMany() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/StarvedMany_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/StarvedMany_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/StarvedMany_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/StarvedMany_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }

    @Test(timeout=21600000)
    public void test_StarvedBinary() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Instances data;
            InputStreamReader file = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/StarvedBinary_" + iter + "_training.arff"));
            try(BufferedReader reader = new BufferedReader(file);) {
                data = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/StarvedBinary_" + iter + "_training.arff", e);
            }
            data.setClassIndex(data.numAttributes()-1);
            Instances testdata;
            InputStreamReader testfile = new InputStreamReader(
                    this.getClass().getResourceAsStream("/smokedata/StarvedBinary_" + iter + "_test.arff"));
            try(BufferedReader reader = new BufferedReader(testfile);) {
                testdata = new Instances(reader);
                reader.close();
            }
            catch (IOException e) {
                throw new RuntimeException("error reading file:  smokedata/StarvedBinary_" + iter + "_test.arff", e);
            }
            testdata.setClassIndex(testdata.numAttributes()-1);
            Classifier classifier = AbstractClassifier.forName("weka.classifiers.lazy.KStar", new String[]{});
            classifier.buildClassifier(data);
            for (Instance instance : testdata) {
                classifier.classifyInstance(instance);
                classifier.distributionForInstance(instance);
            }
        }
    }


}