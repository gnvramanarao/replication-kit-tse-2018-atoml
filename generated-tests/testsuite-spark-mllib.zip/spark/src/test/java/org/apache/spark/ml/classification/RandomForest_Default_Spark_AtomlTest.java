package org.apache.spark.ml.classification;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;


import javax.annotation.Generated;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.io.IOException;
import weka.core.Attribute;
import weka.core.Instances;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.ml.feature.OneHotEncoderEstimator;
import org.apache.spark.ml.feature.OneHotEncoderModel;
import org.apache.spark.ml.feature.VectorAssembler;

/**
 * Automatically generated smoke and metamorphic tests.
 */
@Generated("atoml.testgen.TestclassGenerator")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RandomForest_Default_Spark_AtomlTest {

    private SparkSession sparkSession;
	
    @Before
    public void setUp() {
        sparkSession = SparkSession.builder().appName("Logistic_Default_AtomlTest").master("local[1]").getOrCreate();
        sparkSession.sparkContext().setLogLevel("WARN");
    }
    
    @After
    public void tearDown() {
        sparkSession.stop();
    }

    public Dataset<Row> arffToDataset(String filename) {
		Instances data;
		InputStreamReader file = new InputStreamReader(this.getClass().getResourceAsStream(filename));
		try (BufferedReader reader = new BufferedReader(file);) {
			data = new Instances(reader);
			reader.close();
		} catch (IOException e) {
			throw new RuntimeException(filename, e);
		}

		List<StructField> fields = new LinkedList<>();
		for (int j = 0; j < data.numAttributes(); j++) {
			fields.add(DataTypes.createStructField(getNormalizedName(data.attribute(j)), DataTypes.DoubleType, false));
		}
		StructType schema = DataTypes.createStructType(fields);
		List<Row> rows = new LinkedList<>();
		for (int i = 0; i < data.size(); i++) {
			List<Double> valueList = new ArrayList<>(data.numAttributes());
			for (int j = 0; j < data.numAttributes(); j++) {
				valueList.add(data.instance(i).value(j));
			}

			rows.add(RowFactory.create(valueList.toArray()));
		}
		Dataset<Row> dataframe = sparkSession.createDataFrame(rows, schema);

		List<String> featureNames = new ArrayList<>();
		List<String> nominals = new LinkedList<>();
		List<String> nominalsOutput = new LinkedList<>();
		for (int j = 0; j < data.numAttributes() - 1; j++) {
			featureNames.add(getNormalizedName(data.attribute(j)));
			if (data.attribute(j).isNominal()) {
				nominals.add(getNormalizedName(data.attribute(j)));
				nominalsOutput.add(getNormalizedName(data.attribute(j)) + "_onehot");
			}
		}
		if (!nominals.isEmpty()) {
			OneHotEncoderEstimator oneHot = new OneHotEncoderEstimator().setInputCols(nominals.toArray(new String[0]))
					.setOutputCols(nominalsOutput.toArray(new String[0])).setDropLast(false);
			OneHotEncoderModel oneHotModel = oneHot.fit(dataframe);
			dataframe = oneHotModel.transform(dataframe);
			dataframe = dataframe.drop(nominals.toArray(new String[0]));
			for (int j = nominals.size() - 1; j >= 0; j--) {
				dataframe = dataframe.withColumnRenamed(nominalsOutput.get(j), nominals.get(j));
			}
		}
		VectorAssembler va = new VectorAssembler().setInputCols(featureNames.toArray(new String[0]))
				.setOutputCol("features");
		dataframe = va.transform(dataframe);

		return dataframe;
	}
    
    public String getNormalizedName(Attribute attribute) {
    	return attribute.name().replaceAll("\\.", "_");
    }

    @Test
    public void test_Const_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Const.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Const_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Const.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Const_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Const.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Const_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Const.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDCAT_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDCAT_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CATEGORICAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CATEGORICAL_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CREDITG_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CREDITG_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Opposite_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + "_Opposite.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) != 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDCAT_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDCAT_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CATEGORICAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CATEGORICAL_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CREDITG_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CREDITG_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Scramble_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + "_Scramble.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDCAT_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDCAT_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CATEGORICAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CATEGORICAL_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CREDITG_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CREDITG_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Reorder_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + "_Reorder.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDCAT_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDCAT_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CATEGORICAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CATEGORICAL_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CREDITG_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CREDITG_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Same_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + "_Same.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(dataframe).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_RANDNUM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDNUM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDNUM_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_UNIFORM() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNIFORM_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNIFORM_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_RANDCAT() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/RANDCAT_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/RANDCAT_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_CATEGORICAL() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CATEGORICAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CATEGORICAL_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_CREDITG() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/CREDITG_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/CREDITG_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_IONOSPHERE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/IONOSPHERE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/IONOSPHERE_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_UNBALANCE() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/UNBALANCE_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/UNBALANCE_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_WEATHERNOMINAL() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNOMINAL_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Rename_WEATHERNUMERIC() throws Exception {
        for(int iter=1; iter<=1; iter++) {
            Dataset<Row> dataframe = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + ".arff");
            Dataset<Row> morpheddata = arffToDataset("/morphdata/WEATHERNUMERIC_" + iter + "_Rename.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            RandomForestClassifier morphedClassifier = new RandomForestClassifier();
            morphedClassifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = morphedClassifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(morphedClassifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            ClassificationModel<?, ?> morphedModel = morphedClassifier.fit(morpheddata);
            
            List<Row> predictionOriginal = model.transform(dataframe).select("prediction").collectAsList();
            List<Row> predictionMorphed = morphedModel.transform(morpheddata).select("prediction").collectAsList();

            
            int violations = 0;
            for (int i = 0; i < predictionOriginal.size(); i++) {
                double originalClass = predictionOriginal.get(i).getDouble(0);
                double morphedClass = predictionMorphed.get(i).getDouble(0);
                if (!(Double.compare(originalClass, morphedClass) == 0)) {
                    violations++;
                }
            }
            if (violations > 0) {
                assertEquals("metamorphic relation broken (iteration " + iter + "): " + violations + " violations",0, violations);
            }
        }
    }

    @Test
    public void test_Uniform() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/Uniform_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/Uniform_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_MinFloat() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/MinFloat_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/MinFloat_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_VerySmall() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/VerySmall_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/VerySmall_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_MinDouble() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/MinDouble_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/MinDouble_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_MaxFloat() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/MaxFloat_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/MaxFloat_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_VeryLarge() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/VeryLarge_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/VeryLarge_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_MaxDouble() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/MaxDouble_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/MaxDouble_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_Split() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/Split_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/Split_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_LeftSkew() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/LeftSkew_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/LeftSkew_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_RightSkew() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/RightSkew_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/RightSkew_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_OneClass() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/OneClass_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/OneClass_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_Bias() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/Bias_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/Bias_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_Outlier() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/Outlier_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/Outlier_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_Zeroes() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/Zeroes_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/Zeroes_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_RandomNumeric() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/RandomNumeric_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/RandomNumeric_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_RandomCategorial() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/RandomCategorial_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/RandomCategorial_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_DisjointNumeric() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/DisjointNumeric_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/DisjointNumeric_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_DisjointCategorical() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/DisjointCategorical_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/DisjointCategorical_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_ManyCategories() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/ManyCategories_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/ManyCategories_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_StarvedMany() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/StarvedMany_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/StarvedMany_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }

    @Test
    public void test_StarvedBinary() throws Exception {
        for(int iter=1; iter<=5; iter++) {
            Dataset<Row> dataframe = arffToDataset("/smokedata/StarvedBinary_" + iter + "_training.arff");
            Dataset<Row> testdata = arffToDataset("/smokedata/StarvedBinary_" + iter + "_test.arff");
            
            RandomForestClassifier classifier = new RandomForestClassifier();
            classifier.setLabelCol("classAtt");
            try {
            	Method setSeedMethod = classifier.getClass().getMethod("setSeed", long.class);
            	setSeedMethod.invoke(classifier, 42);
            } catch (NoSuchMethodException | SecurityException e) {
            	// not randomized
            }
            
            ClassificationModel<?, ?> model = classifier.fit(dataframe);
            model.transform(testdata);
        }
    }


}