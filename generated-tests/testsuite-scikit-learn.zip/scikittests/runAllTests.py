import unittest
import xmlrunner

with open('test-export-scikit.xml', 'wb') as output:
	test_results = xmlrunner.XMLTestRunner(output=output).run(unittest.TestLoader().discover(".", "test_*.py"))
